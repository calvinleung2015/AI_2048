from __future__ import absolute_import, division, print_function
import copy, random
from game import Game
import math


MOVES = {0: 'up', 1: 'left', 2: 'down', 3: 'right'}
MAX_PLAYER, CHANCE_PLAYER = 0, 1 

# Tree node. To be used to construct a game tree. 
class Node: 
    # Recommended: do not modify this __init__ function
    def __init__(self, state, player_type):
        self.state = (copy.deepcopy(state[0]), state[1])

        # to store a list of (direction, node) tuples
        self.children = []
        self.player_type = player_type

    # returns whether this is a terminal state (i.e., no children)
    def is_terminal(self):
        #TODO: complete this
        return len(self.children) == 0

# AI agent. To be used do determine a promising next move.
class AI:
    # Recommended: do not modify this __init__ function
    def __init__(self, root_state, search_depth=3): 
        self.root = Node(root_state, MAX_PLAYER)
        self.search_depth = search_depth
        self.simulator = Game(*root_state)


    # recursive function to build a game tree
    def build_tree(self, node=None, depth=0, ec=False):
        if node == None: ###the node is the current node
            node = self.root
        if depth == self.search_depth: #base case
            self.simulator.reset(node.state[0], node.state[1])
            return

        if node.player_type == MAX_PLAYER:
            # TODO: find all children resulting from 
            # all possible moves (ignore "no-op" moves)
            self.simulator.reset(node.state[0], node.state[1])
            for d in MOVES:
                if self.simulator.move(d) == True:
                    state = self.simulator.get_state()
                    new_node = Node(state, CHANCE_PLAYER)
                    node.children.append((d, new_node))
                    self.simulator.undo()

        elif node.player_type == CHANCE_PLAYER:
            # TODO: find all children resulting from 
            # all possible placements of '2's
            # NOTE: the following calls may be useful
            # (in addition to those mentioned above):
            # self.simulator.get_open_tiles():

            self.simulator.reset(node.state[0], node.state[1])
            for spot in self.simulator.get_open_tiles():
                self.simulator.tile_matrix[spot[0]][spot[1]] = 2
                state = self.simulator.get_state()
                new_node = Node(state, MAX_PLAYER)
                node.children.append((None, new_node))
                self.simulator.tile_matrix[spot[0]][spot[1]] = 0

        # TODO: build a tree for each child of this node
        for n in node.children:
            self.build_tree(n[1], depth+1, ec=False)








    # expectimax implementation; 
    # returns a (best direction, best value) tuple if node is a MAX_PLAYER
    # and a (None, expected best value) tuple if node is a CHANCE_PLAYER
    def expectimax(self, node = None):

        if node == None:
            node = self.root

        if node.is_terminal():
            # TODO: base case
            payoff = node.state[1]
            return None, payoff

        elif node.player_type == MAX_PLAYER:
            # TODO: MAX_PLAYER logic
            score_best = -math.inf
            d_best = 0
            score_best = float(score_best)
            init_score = score_best
            for d, child_node in node.children:
                current_score = self.expectimax(child_node)[1]
                score_best = max(score_best, current_score)
                if score_best > init_score:
                    d_best = d
            return d_best, score_best
        

        elif node.player_type == CHANCE_PLAYER:
            # TODO: CHANCE_PLAYER logic
            value = 0
            for d, child_node in node.children:
                value = value + self.expectimax(child_node)[1] / (len(node.children))
            return None, value


    # Do not modify this function
    def compute_decision(self):
        self.build_tree()
        direction, _ = self.expectimax(self.root)
        return direction

    # TODO (optional): implement method for extra credits
    def compute_decision_ec(self):
        # TODO delete this
        return random.randint(0, 3)




